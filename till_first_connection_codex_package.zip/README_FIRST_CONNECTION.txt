TILL / FIRST CONNECTION — asset handoff (approved visual set)

Main background: background/office_empty_approved.png is the newly approved empty office. It is 4:3, NOT portrait; do not stretch or crop once and assume the entire environment stays visible. Use a controlled virtual-camera pan or produce a deliberately reframed portrait environment after approval. The reference/phone_crop_study.png shows exactly what 9:16 crops retain.

Character poses sequence:
01 working, clipboard.
02 looking upward towards the viewer, who seems to be above Till.
03 reacting to an unexpectedly loud user voice. Note clipboard/papers/pen are still part of this composite; avoid layering duplicates on top.
04 introducing himself, pointing to name badge; crooked glasses/dirty shirt/pen in hair.
05 describing how he helps shift employees; same messy continuity.
06 reacting as boxes fall (props to animate independently).
07 recovering with sheepish thumbs up.

All character PNGs are RGBA cutouts but must undergo edge/halo QA against both dark and bright backgrounds, especially blond hair. Different pose proportions and perspective require careful hand-aligned anchor points and understated transitions; images are not a 3D rig and cannot be used for true lip sync. Do not promise natural articulated speech motion from static PNGs.

Props: separate closed boxes, one open box spilling peanuts, and peanut cluster. These are cutout props, not physics. Keep their falling motion behind Till and out of the key task UI.

Design and workflow constraints:
- App name is Shift Guide, NOT Kayla's Shift Guide.
- Casey's office branding has NO cross atop the sign.
- Preserve working Shift Guide logic, all first-run name/setup and PWA installation flow.
- New interactive scene is skippable, replayable, shown once after onboarding; return users go directly home.
- The user voice is an interactive choice with prerecorded/processed booming voice, no mic permission needed.
- Reference the exact app content and AI_HANDOFF.md before implementation; don't invent new operational tasks.
- The user wants polished, warm 3D-style art, natural timing, and Till as a recurring helpful coworker, not blocking work.
- Build on feature branch, preview/test before merge or deploy.

Sound/voice audio is NOT included. Treat voices as a distinct future production requirement; captions can operate without them. The scene background is not layered, so any occlusion between Till and desk must be handled thoughtfully.
