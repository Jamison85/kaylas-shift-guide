# Codex build brief: Till's First Connection

## Mission
Build a **standalone, phone-first interactive prototype** of Till's first meeting with the user, titled **“Hello? Is Somebody Up There?”**, for GitHub repository `Jamison85/kaylas-shift-guide`. Treat this as an experimental preview on a feature branch, **not** as permission to change or deploy the production app.

This packet includes the approved Till character poses, approved empty headquarters background, separate falling-box props, a crop reference, and this brief. Read `README_FIRST_CONNECTION.txt` and `asset_manifest.json` first.

## Start by inspecting the actual repository
1. Read `AI_HANDOFF.md`, `README.md`, `src/App.jsx`, `src/components/CharacterProp.jsx`, `src/data/guide.js`, `src/styles.css`, `vite.config.js`, and existing Playwright tests.
2. The current repository's **actual app title in `src/App.jsx` is `Before the Rush`**. The approved *in-world monitor artwork* says **“Shift Guide”**. Respect both. Do not rename the real app, change its brand or copy, or label this experience “Kayla's” without explicit future approval.
3. Existing install invitation comes before name setup on fresh mobile browser visits. Preserve its bypass and all PWA behavior. Existing returning users enter Home directly. The new intro must not interfere with this in a preview.
4. The project has React 18 + Vite 6, localStorage persistence, CSS character poses, and Playwright tests. Avoid large animation frameworks unless justified.

## Deliverable for this pass ONLY
- Implement a self-contained **preview route/page** accessible in local development (for example, a dedicated Vite preview HTML entry or a development-only route) with its own Replay, Skip, Mute, and Start buttons.
- Do not automatically show the intro to existing users, change first-run handling, or wire it into daily operations in this pass.
- Make a feature branch (e.g. `feat/till-first-connection-preview`) and a working preview that can be reviewed on an Android-sized viewport.
- Do not merge, deploy, publish, or modify workflow content. A standalone preview and tests are the goal.

## Asset handling
Source assets inside this pack:
- `background/office_empty_approved.png`: approved empty office, **1448×1086 landscape 4:3** with red Casey's sign, Shift Guide monitor, reference books, desk, and chair. Do not stretch to 9:16, replace it with another room, add a cross to the Casey's logo, or add “Kayla” to signage.
- `character/01_working.png`: clean Till seated/working with clipboard.
- `character/02_notices_viewer.png`: Till looks **up** toward a viewer high above his tiny world, not straight ahead at someone standing at his eye level.
- `character/03_booming_voice.png`: shocked Till with a flying pen/papers/clipboard already baked into the pose. Do **not** overlay duplicate clipboard props.
- `character/04_introducing.png`: disheveled Till pointing to badge; filthy red polo, tilted glasses, pen in his hair, original pocket pens.
- `character/05_explaining.png`: same post-shock continuity; proud/helpful explanation gesture.
- `character/06_boxes_falling.png`: reacting to impending box collapse; no office baked in.
- `character/07_recovery.png`: awkward thumbs-up while dusty after incident.
- `props/box_left.png`, `box_center.png`, `box_right.png`, `box_open_peanuts.png`, `peanuts_loose.png`: independent props, composited and animated behind Till.
- `reference/approved_original_till.png`: canonical appearance reference only.
- `reference/phone_crop_study.png`: helps assess portrait crop of the approved landscape office.

Character assets have alpha transparency, but require visual edge/halo checks on dark AND light backgrounds. Use consistent *visible character scale* and foot/torso/eye anchors, **not** the image rectangles alone; images have different margins and framing. Keep perspective coherent. Never treat these poses as a fully rigged 3D model or use generic linear cross-fades as the only character animation. Layer subtle movement, anticipation, secondary motion, timed pose exchanges, parallax and well-timed reactions. Do not stretch characters or crop faces to fit. Use neutral stage lighting consistent with the office. Include a clean compositing test on phone screen.

## Narrative and interactive flow
Aim for roughly 40–60 seconds **excluding time spent waiting for the user's dialogue selection**. Natural timing and readable captions matter more than an exact duration.

**Scene 1: Routine (opening)**
Show the approved miniature office. Till is working with his clipboard. Ambient desk light/breathing/micro-motion. A subtle notification sounds; a lamp flickers, the office trembles *slightly*.
Till: “That's odd. I don't remember ordering an earthquake.”

**Scene 2: Discovery (looking up)**
From Till's perspective the user is enormous and positioned **above** him as if a giant opening in his world has appeared. Do not render an actual window, door, glass panel, phone frame, portal, or viewer silhouette. Till looks up, notices the viewer, and asks:
“Hello? Is somebody up there?”
Present **two tappable responses** with generous phone touch targets:
A. “Hello, Till!”
B. “I've been watching you.”
Selected user response is represented as an intentionally **enormous booming voice from overhead**, with harmless short visual feedback and spatialized sound only if a real audio file is available. For A: startled Till drops his clipboard; “GOOD GRAVY! Could you turn yourself down a little?!” For B: Till looks nervously at his desk; “Well, that's deeply unsettling. In my defense, I was going to clean that.” Both branches join the same scene thereafter.

**Scene 3: Meet Till / help he gives**
Till gathers composure, glasses crooked and dirty from the shock.
“Right. Well, since we're apparently talking now... I'm Till.”
“I live around here. Keep an eye on things. Help with the shift. Occasionally prevent disasters. Occasionally cause smaller ones.”
He gestures at the office.
“This is my place. Not much to look at, but the rent's fantastic.”
Show that he is a reliable helper for **the existing real app's supported step-by-step opening guide**, not a fictional assistant capable of unsupported live notifications or unrelated functions. The UI art's labels are set dressing, not features to promise.

**Scene 4: Chaos**
Till leans into an unstable cardboard stack staged on the right of the existing office composition.
“Anyway, this Shift Guide will help you keep track of your tasks, stay organized, and avoid any unnecessary...”
Boxes wobble and fall independently behind him; an open box drops packing peanuts. Till reacts. Short, audible crash sound if available. Let the gag breathe for a beat.
“...surprises.”
“Moving on.”
Do not simulate the entire real office structurally collapsing or cover important text with boxes.

**Scene 5: Sign-off and seamless app reveal**
Till dusts himself off.
“You'll see me around. I'll pop in when you need a hand. Sometimes when you don't.”
“Now, you've got a shift to run, and I've got a structural engineer to call.”
Till waves. Stage a **smooth visual reduction/reframing of the miniature office** toward Till's familiar corner/location, while a preview of the real app's existing Home view is revealed. Use the actual current styling/layout for the Home view. Do not fabricate unsupported controls. Till's tiny speech bubble: “Try not to break anything. Apparently that's my department.”
Since this is a prototype, the transition can land on a faithful nonfunctional visual of Home, but no core daily guide behavior may be rewritten.

## Audio reality check
**No finished voiceover or sound-effects files are included.** Implement dialogue as accessible caption/speech bubbles first. Allow future sound file injection via a clearly documented file manifest. You may use a restrained nonverbal WebAudio notification/crash for prototype **if** it respects mute and user-gesture/autoplay restrictions, but do not invent a synthetic voice or pretend real recorded dialogue exists. Booming effect requires a real voice asset later. The user-response button itself must always function without audio.

## UX, performance, accessibility
- Portrait first: verify 360×800, 390×844, and 412×915; also verify desktop and landscape. Use virtual camera framing of the 4:3 approved office; never blindly `object-fit:cover` and assume critical signage/characters stay visible. Use safe areas, correct stage z-index and captions.
- Captions must have ample contrast, remain visible when muted, never cover Till's face, and work at 200% text zoom.
- Obvious Skip / Mute / Replay, keyboard focus, pointer/touch accessibility, reduced-motion alternative, sensible loading state, asset fallback behavior and guaranteed exit to preview Home.
- Pause/resume with page visibility if appropriate. No voice or camera permissions. No external APIs or network dependence.
- Keep new work isolated from `src/data/guide.js`, the existing `CharacterProp`, localStorage user progress keys, install mechanics, Home Start button and PWA caching until separate approval.
- When eventually integrating first-launch playback, respect order: existing optional install invitation → name setup → introduction once → Home. But **do not integrate that automatically in this pass**.
- Disallow autoplay audio before a user gesture. Skipping or cancelling an animation must also stop its pending audio and callbacks.

## Quality bar / stop points
1. Inspect current repo and build a working prototype with **real shipped art**, not placeholder rectangles or a slideshow.
2. Use an explicit scene state machine and deterministic timing, not overlapping ad-hoc setTimeout callbacks.
3. Add tests: branch selection both ways, Skip from every stage, replay, mute, missing audio, reduced motion, narrow screen layout, no first-run regression, and `npm run build` / `npm test`.
4. Provide a preview link or local preview command and short video/screenshots if supported, plus a checklist of defects/limitations. Before asking for merge, explicitly show that Till doesn't double-render, text isn't covered, boxes remain behind character, and the final app reveal isn't abrupt.
5. Do not claim natural lip sync, fully 3D movement, or finished voiceover unless those features actually exist.
6. Stop after the prototype and wait for explicit approval. **No production deployment or merge.**

## Desired final report from Codex
Give branch, files changed, how to preview on phone, demo steps, test results, what needs a voice/sfx recording, what still looks artificial, and exactly what has **not** been deployed.
